import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import "../../services"


PanelWindow {
    id: root

    property bool menuVisible: false
    property bool _mapped: false
    visible: _mapped

  
    property string pendingAction: ""

    readonly property string actionVerb: {
        if (pendingAction === "poweroff")
            return "power off";
        if (pendingAction === "logout")
            return "log out";
        if (pendingAction === "reboot")
            return "reboot";
        return "";
    }

    color: "transparent"

    anchors {
        top: true
        right: true
        bottom: true
        left: true
    }

    exclusiveZone: -1

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
    WlrLayershell.namespace: "quickshell:powermenu"

    function show() {
        _mapped = true;
        menuVisible = true;
    }

    function hide() {
        menuVisible = false;
        pendingAction = "";
        hideTimer.restart();
    }

    function toggle() {
        if (menuVisible)
            hide();
        else
            show();
    }

    function requestAction(action) {
        pendingAction = action;
    }

    function confirmYes() {
        if (pendingAction === "poweroff")
            powerOffProc.running = true;
        else if (pendingAction === "logout")
            logoutProc.running = true;
        else if (pendingAction === "reboot")
            rebootProc.running = true;
        pendingAction = "";
        hide();
    }

    function confirmNo() {
        pendingAction = "";
    }

   
    Timer {
        id: hideTimer
        interval: 220
        onTriggered: root._mapped = false
    }

    Rectangle {
        id: backdrop
        anchors.fill: parent
        color: "#99000000"
        opacity: root.menuVisible ? 0.5 : 0

        Behavior on opacity {
            NumberAnimation { duration: 200 }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: root.hide()
        }

        Keys.onEscapePressed: root.hide()
        focus: root.menuVisible
    }

    
    MultiEffect {
        source: card
        anchors.fill: card
        z: -1
        autoPaddingEnabled: true
        shadowEnabled: root.menuVisible
        shadowColor: "#000000"
        shadowHorizontalOffset: 0
        shadowVerticalOffset: 0
        shadowBlur: 1
        shadowOpacity: 1.0
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        radius: 30
        color: Colors.bg0

        implicitWidth: (root.pendingAction === "" ? buttonRow.implicitWidth : confirmCol.implicitWidth) + 48
        implicitHeight: (root.pendingAction === "" ? buttonRow.implicitHeight : confirmCol.implicitHeight) + 48

        Behavior on implicitWidth {
            NumberAnimation { duration: 200; easing.type: Easing.OutCubic }
        }

        Behavior on implicitHeight {
            NumberAnimation { duration: 200; easing.type: Easing.OutCubic }
        }

        scale: root.menuVisible ? 1.0 : 0.85
        opacity: root.menuVisible ? 1.0 : 0.0
        transformOrigin: Item.Center

        Behavior on scale {
            NumberAnimation {
                duration: 240
                easing.type: Easing.OutBack
                easing.overshoot: 1.3
            }
        }

        Behavior on opacity {
            NumberAnimation { duration: 180 }
        }

        // ---- button row (power/logout/reboot) ----
        RowLayout {
            id: buttonRow
            anchors.centerIn: parent
            spacing: 20
            visible: root.pendingAction === ""

            // ---- Power off ----
            Item {
                Layout.preferredWidth: 240
                Layout.preferredHeight: 240

                MultiEffect {
                    source: powerBtn
                    anchors.fill: powerBtn
                    z: -1
                    autoPaddingEnabled: true
                    shadowEnabled: powerArea.containsMouse || powerArea.pressed
                    shadowColor: Colors.red
                    shadowBlur: 0.8
                    shadowOpacity: 0.9
                    shadowHorizontalOffset: 0
                    shadowVerticalOffset: 0
                }

                Rectangle {
                    id: powerBtn
                    anchors.fill: parent
                    radius: 20
                    color: "#202020"
                    border.color: Colors.red
                    border.width: (powerArea.containsMouse || powerArea.pressed) ? 2 : 0
                    scale: powerArea.pressed ? 0.94 : 1.0

                    Behavior on scale {
                        NumberAnimation { duration: 120; easing.type: Easing.OutQuad }
                    }

                    Behavior on border.width {
                        NumberAnimation { duration: 120 }
                    }

                    Image {
                        anchors.centerIn: parent
                        source: Qt.resolvedUrl("../../assets/icons/power.svg")
                        width: 96
                        height: 96
                        sourceSize.width: 96
                        sourceSize.height: 96
                        smooth: true
                        fillMode: Image.PreserveAspectFit
                    }

                    MouseArea {
                        id: powerArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.requestAction("poweroff")
                    }
                }
            }

            // ---- Logout ----
            Item {
                Layout.preferredWidth: 240
                Layout.preferredHeight: 240

                MultiEffect {
                    source: logoutBtn
                    anchors.fill: logoutBtn
                    z: -1
                    autoPaddingEnabled: true
                    shadowEnabled: logoutArea.containsMouse || logoutArea.pressed
                    shadowColor: Colors.green
                    shadowBlur: 0.8
                    shadowOpacity: 0.9
                    shadowHorizontalOffset: 0
                    shadowVerticalOffset: 0
                }

                Rectangle {
                    id: logoutBtn
                    anchors.fill: parent
                    radius: 20
                    color: "#202020"
                    border.color: Colors.green
                    border.width: (logoutArea.containsMouse || logoutArea.pressed) ? 2 : 0
                    scale: logoutArea.pressed ? 0.94 : 1.0

                    Behavior on scale {
                        NumberAnimation { duration: 120; easing.type: Easing.OutQuad }
                    }

                    Behavior on border.width {
                        NumberAnimation { duration: 120 }
                    }

                    Image {
                        anchors.centerIn: parent
                        source: Qt.resolvedUrl("../../assets/icons/logout.svg")
                        width: 96
                        height: 96
                        sourceSize.width: 96
                        sourceSize.height: 96
                        smooth: true
                        fillMode: Image.PreserveAspectFit
                    }

                    MouseArea {
                        id: logoutArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.requestAction("logout")
                    }
                }
            }

            // ---- Reboot ----
            Item {
                Layout.preferredWidth: 240
                Layout.preferredHeight: 240

                MultiEffect {
                    source: rebootBtn
                    anchors.fill: rebootBtn
                    z: -1
                    autoPaddingEnabled: true
                    shadowEnabled: rebootArea.containsMouse || rebootArea.pressed
                    shadowColor: Colors.yellow
                    shadowBlur: 0.8
                    shadowOpacity: 0.9
                    shadowHorizontalOffset: 0
                    shadowVerticalOffset: 0
                }

                Rectangle {
                    id: rebootBtn
                    anchors.fill: parent
                    radius: 20
                    color: "#202020"
                    border.color: Colors.yellow
                    border.width: (rebootArea.containsMouse || rebootArea.pressed) ? 2 : 0
                    scale: rebootArea.pressed ? 0.94 : 1.0

                    Behavior on scale {
                        NumberAnimation { duration: 120; easing.type: Easing.OutQuad }
                    }

                    Behavior on border.width {
                        NumberAnimation { duration: 120 }
                    }

                    Image {
                        anchors.centerIn: parent
                        source: Qt.resolvedUrl("../../assets/icons/reboot.svg")
                        width: 96
                        height: 96
                        sourceSize.width: 96
                        sourceSize.height: 96
                        smooth: true
                        fillMode: Image.PreserveAspectFit
                    }

                    MouseArea {
                        id: rebootArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.requestAction("reboot")
                    }
                }
            }
        }

        // ---- confirmation prompt ----
        ColumnLayout {
            id: confirmCol
            anchors.centerIn: parent
            spacing: 16
            visible: root.pendingAction !== ""

            Rectangle {
                Layout.preferredWidth: 420
                implicitHeight: questionText.implicitHeight + 32
                radius: 16
                color: "#202020"

                Text {
                    id: questionText
                    anchors.centerIn: parent
                    anchors.margins: 16
                    width: parent.width - 32
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: "Are you sure you want to " + root.actionVerb + "?"
                    color: Colors.fg
                    font.pixelSize: 18
                    font.family: Colors.fontFamily
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 16

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    radius: 16
                    color: (yesArea.containsMouse || yesArea.pressed) ? "#272727" : "#202020"

                    Behavior on color {
                        ColorAnimation { duration: 120 }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "Yes"
                        color: Colors.fg
                        font.pixelSize: 16
                        font.family: Colors.fontFamily
                    }

                    MouseArea {
                        id: yesArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.confirmYes()
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    radius: 16
                    color: (noArea.containsMouse || noArea.pressed) ? "#272727" : "#202020"

                    Behavior on color {
                        ColorAnimation { duration: 120 }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "No"
                        color: Colors.fg
                        font.pixelSize: 16
                        font.family: Colors.fontFamily
                    }

                    MouseArea {
                        id: noArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.confirmNo()
                    }
                }
            }
        }
    }

    
    Process {
        id: powerOffProc
        command: ["systemctl", "poweroff"]
    }

    Process {
        id: logoutProc
        command: ["hyprctl", "dispatch", "exit"]
    }

    Process {
        id: rebootProc
        command: ["systemctl", "reboot"]
    }
}