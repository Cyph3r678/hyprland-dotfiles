import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Effects
import "../../services"
import "."

// Top-center battery status popup. Toggled via shell.qml's IPC
// "battery" target (toggle()/show()/hide()):
//
//   BatteryWindow { id: batteryWindow }
//
//   IpcHandler {
//       target: "battery"
//       function toggle(): void { batteryWindow.toggle(); }
//       function show(): void { batteryWindow.show(); }
//       function hide(): void { batteryWindow.hide(); }
//   }
PanelWindow {
    id: panel

   
    PersistentProperties {
        id: persist
        reloadableId: "qspanel-battery-window"

        property bool panelVisible: false
        // 0 = hidden (shrunk down, invisible), 1 = fully open.
        property real openProgress: 0

        Behavior on openProgress {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutBack
                easing.overshoot: 1.4 // noticeably poppier than the
                                       // widgets panel - this one's
                                       // meant to feel like it's
                                       // popping out
            }
        }
    }

    // Ordinary reactive binding, not a one-shot assignment - stays
    // true for the whole close animation and flips false right as it
    // settles, with no callback/timing logic needed.
    visible: persist.openProgress > 0.001

    color: "transparent"

    
    readonly property real topGap: 12
    readonly property real cardWidth: 460
    readonly property real cardHeight: card.implicitHeight + Colors.panelPadding * 2
    readonly property real shadowPadding: 48

    implicitWidth: cardWidth + shadowPadding
    implicitHeight: cardHeight + topGap + shadowPadding

    anchors {
        top: true
        left: true
    }
    
    readonly property real screenWidth: panel.screen ? panel.screen.width : 1920
    margins.left: Math.round((screenWidth - implicitWidth) / 2)

    exclusiveZone: 0
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand
    WlrLayershell.namespace: "qspanel:battery"

    mask: Region {
        x: panel.shadowPadding / 2
        y: panel.topGap
        width: persist.openProgress > 0.01 ? panel.cardWidth : 0
        height: persist.openProgress > 0.01 ? panel.cardHeight : 0
    }

    function show() {
        persist.panelVisible = true;
        persist.openProgress = 1;
    }

    function hide() {
        persist.panelVisible = false;
        persist.openProgress = 0;
    }

    function toggle() {
        if (persist.panelVisible)
            hide();
        else
            show();
    }

    MultiEffect {
        source: background
        anchors.fill: background
        z: -1
        autoPaddingEnabled: true
        shadowEnabled: persist.panelVisible
        shadowColor: "#73000000"
        shadowHorizontalOffset: 0
        shadowVerticalOffset: 5
        shadowBlur: 1
        shadowOpacity: 1.0
    }

    Rectangle {
        id: background
        x: panel.shadowPadding / 2
        y: panel.topGap
        width: panel.cardWidth
        height: panel.cardHeight
        radius: Colors.radiusOuter
        color: Colors.bg0
        clip: true // safety net, same reasoning as the widgets card

        transformOrigin: Item.Top
        scale: 0.4 + persist.openProgress * 0.6
        opacity: persist.openProgress

        BatteryCard {
            id: card
            anchors.fill: parent
            anchors.margins: Colors.panelPadding
        }
    }
}