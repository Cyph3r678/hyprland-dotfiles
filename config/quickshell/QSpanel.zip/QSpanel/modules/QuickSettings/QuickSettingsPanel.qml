import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import "../../services"


PanelWindow {
    id: panel

    property bool panelVisible: false
    signal requestClose()

   
    property bool _mapped: false
    visible: _mapped

    color: "transparent"

    readonly property real cardWidth: 420
    readonly property real cardHeight: content.implicitHeight + Colors.panelPadding * 2
    readonly property real shadowPadding: 64

    implicitWidth: cardWidth + shadowPadding
    implicitHeight: cardHeight + shadowPadding

    anchors {
        top: true
        right: true
    }

    margins {
        top: 16
        right: 16
    }

    exclusiveZone: 0

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand
    WlrLayershell.namespace: "quickshell:quicksettings"

    mask: Region {
        item: background
    }

    property real slideX: cardWidth

    Behavior on slideX {
        NumberAnimation {
            id: slideAnim
            duration: 380
          
            easing.type: Easing.OutBack
            easing.overshoot: 1.8
            onFinished: {
              
                if (!panel.panelVisible)
                    panel._mapped = false;
            }
        }
    }

    onPanelVisibleChanged: {
        if (panelVisible) {
            _mapped = true;
            slideX = 0;
        } else {
            slideX = cardWidth;
        }
    }

    MultiEffect {
        source: background
        anchors.fill: background
        z: -1
        autoPaddingEnabled: true
        shadowEnabled: panel.panelVisible
        shadowColor: "#73000000"   // rgba(00000073) -> Qt's #AARRGGBB
        shadowHorizontalOffset: -4
        shadowVerticalOffset: 4
        shadowBlur: 1
        shadowOpacity: 1.0
    }

    Rectangle {
        id: background
        x: panel.shadowPadding + panel.slideX
        y: 0
        width: panel.cardWidth
        height: panel.cardHeight
        radius: Colors.radiusOuter
        color: Colors.bg0

        ColumnLayout {
            id: content
            anchors.fill: parent
            anchors.margins: Colors.panelPadding
            spacing: Colors.gapLg

            ProfileCard {
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: Colors.gapLg

                WifiTile {
                    Layout.fillWidth: true
                }

                BluetoothTile {
                    Layout.fillWidth: true
                }
            }

            BrightnessSlider {
                Layout.fillWidth: true
            }

            VolumeSlider {
                Layout.fillWidth: true
            }

            MediaPlayerCard {
                Layout.fillWidth: true
            }
        }
    }
}