import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import "../../services"
import "."

// Left-edge widgets panel. Manually toggled (like QuickSettingsPanel),
// not auto-hide. shell.qml's IPC "widgets" target calls
// toggle()/show()/hide().
PanelWindow {
    id: panel

    property bool panelVisible: false
    property bool _mapped: false
    visible: _mapped

    color: "transparent"

    readonly property real cardWidth: 660
    readonly property real cardHeight: content.implicitHeight + Colors.panelPadding * 2
    // Padding only on the right/bottom - the card stays flush against
    // the window's top/left edges, same reasoning as
    // QuickSettingsPanel's left/bottom-only padding (mirrored, since
    // this one is anchored top-left instead of top-right).
    readonly property real shadowPadding: 64

    implicitWidth: cardWidth + shadowPadding
    implicitHeight: cardHeight + shadowPadding

    anchors {
        top: true
        left: true
    }

    margins {
        top: 12
        left: 12
    }

    exclusiveZone: 0

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand
    WlrLayershell.namespace: "quickshell:widgets"

    mask: Region {
        item: background
    }

    // 0 = fully in place, -cardWidth = fully off-screen to the left.
    property real slideX: -cardWidth

    Behavior on slideX {
        NumberAnimation {
            duration: 380
            easing.type: Easing.OutBack
            easing.overshoot: 1.8
            onFinished: {
                if (!panel.panelVisible)
                    panel._mapped = false;
            }
        }
    }

    function show() {
        _mapped = true;
        panelVisible = true;
        slideX = 0;
    }

    function hide() {
        panelVisible = false;
        slideX = -cardWidth;
    }

    function toggle() {
        if (panelVisible)
            hide();
        else
            show();
    }

    MultiEffect {
        source: background
        anchors.fill: background
        z: -1
        autoPaddingEnabled: true
        // Tied to panelVisible, not just true - see QuickSettingsPanel.qml
        // / OsdWindow.qml for why an always-on shadow leaks into view
        // once the card has slid fully off-screen.
        shadowEnabled: panel.panelVisible
        shadowColor: "#73000000"
        shadowHorizontalOffset: 5
        shadowVerticalOffset: 5
        shadowBlur: 1
        shadowOpacity: 1.0
    }

    Rectangle {
        id: background
        // slideX itself carries the card fully off-screen to the left
        // when hidden; no extra shadowPadding offset needed in x here
        // since the card is meant to sit flush at x=0 (the window's
        // own left edge) when open, unlike QuickSettingsPanel where
        // the card needed to be pushed right by shadowPadding to stay
        // flush with the window's right edge instead.
        x: panel.slideX
        y: 0
        width: panel.cardWidth
        height: panel.cardHeight
        radius: Colors.radiusOuter
        color: Colors.bg0
        clip: true // last line of defense: if a card's height is ever
                    // wrong again, this contains the damage to "looks
                    // slightly off" instead of "text on the desktop"

        RowLayout {
            id: content
            anchors.fill: parent
            anchors.margins: Colors.panelPadding
            spacing: Colors.gapLg

            // Explicit pixel widths for BOTH columns - no Layout.fillWidth
            // anywhere in this split. This is the one genuinely new
            // layout pattern in the whole project (every other panel
            // here is a single column) - mixing a fixed-width sibling
            // with a fillWidth sibling in the same RowLayout is exactly
            // the kind of ambiguous constraint that can make one
            // collapse to near-zero width instead of behaving as
            // expected, which matches the squished-calendar symptom far
            // better than anything inside CalendarCard itself.
            readonly property real leftColWidth: 240
            readonly property real calendarColWidth: width - leftColWidth - spacing

            ColumnLayout {
                Layout.preferredWidth: content.leftColWidth
                Layout.maximumWidth: content.leftColWidth
                Layout.fillHeight: true
                spacing: Colors.gapLg

                ClockCard {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 160
                }

                RemindersCard {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                }
            }

            CalendarCard {
                Layout.preferredWidth: content.calendarColWidth
                Layout.maximumWidth: content.calendarColWidth
                Layout.fillHeight: true
            }
        }
    }
}